# 广告日报分片Chart发布设计

starter/chart/ad-report保存Chart骨架、分片清单、失败处置策略和发布参数。请完成templates/resources.yaml，再运行npm run build-release。

入口使用Helm3.17.3执行严格lint与离线template。正常完成后，同级output包含完成Chart、渲染对象和发布报告。作业不连接Kubernetes集群、镜像仓库或广告平台。
